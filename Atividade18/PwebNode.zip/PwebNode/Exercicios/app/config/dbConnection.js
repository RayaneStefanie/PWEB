var sql = require('mssql/msnodesqlv8');
module.exports = function () {

    const config = {
        user: 'BD2123037',
        password: 'A12345678a',
        database: 'BD', //Na FATEC, utilizar o database BD ou LP8 
        server: 'APOLO',//Caso o nome tenha uma instância, colocar duas
        driver: 'msnodesqlv8',
    }
    return sql.connect(config);
}